import 'package:flutter/material.dart';
class Page1 extends StatelessWidget {
  const Page1({Key? key}) : super(key: key);

  @override
    Widget build(BuildContext context) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('Akun Bisnis Saya'),
          ),
          body: Builder(
              builder: (context) {
                return SingleChildScrollView(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text ('Kasman'),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text ('19201306'),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image(
                            image: NetworkImage(
                                'https://i.postimg.cc/13fdWMKV/kasman.jpg'),


                          ),
                        ),
                        ElevatedButton(
                          onPressed: () => myDialog(context),
                          child: Text('kontak saya'),
                        )
                      ],
                    ),
                  ),
                );
              }
          ),
        ),
      );
    }

  myDialog(BuildContext context) {}
  }

