import 'package:flutter/material.dart';
class Page2 extends StatefulWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  State<Page2> createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('produk'),
        ),
        body: Builder(
            builder: (context) {
              return SingleChildScrollView(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text ('CASING'),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text ('BLACKDOFF'),

                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.network('https://i.postimg.cc/pX0QvCFp/bl.jpg'),
                      ),
                      ElevatedButton(
                        onPressed: () => myDialog(context),
                        child: Text('check out'),
                      )
                    ],
                  ),
                ),
              );
            }
        ),
      ),
    );
  }

  myDialog(BuildContext context) {}
}

